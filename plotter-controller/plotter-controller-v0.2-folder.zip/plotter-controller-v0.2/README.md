# Plotter Controller
Управление перьевым плоттером через GRBL 1.1. Node.js ≥ 18.
    npm install && npm start      # http://localhost:8765
    npm test                      # проверка SVG → G-code
Linux: добавьте пользователя в группу `dialout`.
Бумага ≤ A4, начало координат — левый верхний угол, Y растёт вниз. «0» в джойстике = `G10 L20 P1 X0 Y0`.
