// GRBL 1.1 settings reference: id -> [name, unit]
const S = {
 0:['Step pulse','µs'],1:['Step idle delay','ms'],2:['Step port invert','mask'],3:['Direction port invert','mask'],
 4:['Step enable invert','bool'],5:['Limit pins invert','bool'],6:['Probe pin invert','bool'],10:['Status report','mask'],
 11:['Junction deviation','mm'],12:['Arc tolerance','mm'],13:['Report inches','bool'],20:['Soft limits','bool'],
 21:['Hard limits','bool'],22:['Homing cycle','bool'],23:['Homing dir invert','mask'],24:['Homing feed','mm/min'],
 25:['Homing seek','mm/min'],26:['Homing debounce','ms'],27:['Homing pull-off','mm'],30:['Max spindle speed','RPM'],
 31:['Min spindle speed','RPM'],32:['Laser mode','bool'],100:['X steps/mm','steps/mm'],101:['Y steps/mm','steps/mm'],
 102:['Z steps/mm','steps/mm'],110:['X max rate','mm/min'],111:['Y max rate','mm/min'],112:['Z max rate','mm/min'],
 120:['X acceleration','mm/s²'],121:['Y acceleration','mm/s²'],122:['Z acceleration','mm/s²'],
 130:['X max travel','mm'],131:['Y max travel','mm'],132:['Z max travel','mm']};
// Moderate speeds for a gravity-fed pen carriage; steps/mm and travel are machine-specific, so not touched
const PRESET_PEN_PLOTTER = { 110: 3000, 111: 3000, 120: 100, 121: 100, 32: 0 };
const ERRORS = { 1:'G-code word without a number',2:'Bad number format',3:'Unknown $ command',8:'$ command needs idle state',
 9:'Locked (alarm or jog) — use $X',15:'Jog target exceeds machine travel',20:'Unsupported/unknown G-code command',
 22:'Feed rate not set',23:'Integer value expected',33:'Invalid G-code target',38:'Line number too large' };
module.exports = { SETTINGS: S, PRESET_PEN_PLOTTER, ERRORS };
