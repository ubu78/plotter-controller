const express = require('express');
const http = require('http');
const path = require('path');
const { WebSocketServer } = require('ws');
const Grbl = require('./grbl');
const { svgToGcode } = require('./svgToGcode');
const { textToGcode, FONTS } = require('./textToGcode');
const { docToText } = require('./docToText');
const { SETTINGS, PRESET_PEN_PLOTTER } = require('./grblSettings');

const app = express(), grbl = new Grbl();
app.use(express.json({ limit: '30mb' }));
app.use(express.static(path.join(__dirname, '..', 'dist')));

const wrap = fn => async (req, res) => { try { res.json((await fn(req)) ?? { ok: true }); } catch (e) { res.status(400).json({ error: e.message }); } };
app.get('/api/status', (_q, r) => r.json(grbl.status));
app.get('/api/ports', wrap(async () => (await Grbl.list()).map(p => ({ path: p.path, name: p.manufacturer || '' }))));
app.post('/api/connect', wrap(q => grbl.connect(q.body.port, q.body.baud)));
app.post('/api/disconnect', wrap(() => grbl.disconnect()));
app.post('/api/send', wrap(q => grbl.send(String(q.body.line))));
app.post('/api/stream', wrap(q => grbl.stream(q.body.gcode)));
app.post('/api/hold', wrap(() => grbl.hold()));
app.post('/api/resume', wrap(() => grbl.resume()));
app.post('/api/stop', wrap(() => grbl.reset()));       // soft reset (Ctrl-X)
app.post('/api/jogcancel', wrap(() => grbl.jogCancel()));
app.get('/api/fonts', (_q, r) => r.json(FONTS));
app.post('/api/text', wrap(q => textToGcode(q.body.text || '', q.body.options)));
app.post('/api/doc', wrap(async q => ({ text: await docToText(q.body.name || '', Buffer.from(q.body.data, 'base64')) })));
app.get('/api/settings', (_q, r) => r.json({ values: grbl.settings, meta: SETTINGS, preset: PRESET_PEN_PLOTTER }));
app.post('/api/svg', wrap(q => svgToGcode(q.body.svg, q.body.options)));

// Quit from the UI: JSON-only (forces a CORS preflight, so other websites cannot trigger it)
app.post('/api/quit', (req, res) => {
  if (!req.is('json')) return res.status(415).json({ error: 'JSON required' });
  res.json({ ok: true });
  grbl.disconnect().catch(() => {}).finally(() => setTimeout(() => process.exit(0), 200));
});
const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: '/ws' });
const bc = m => { const s = JSON.stringify(m); wss.clients.forEach(c => c.readyState === 1 && c.send(s)); };
grbl.on('status', s => bc({ type: 'status', status: s }));
grbl.on('log', l => bc({ type: 'log', line: l }));
let tm; grbl.on('setting', () => { clearTimeout(tm); tm = setTimeout(() => bc({ type: 'settings', values: grbl.settings }), 200); });
wss.on('connection', ws => ws.send(JSON.stringify({ type: 'status', status: grbl.status })));

const PORT = process.env.PORT || 8765;
server.listen(PORT, '127.0.0.1', () => console.log(`Plotter Controller: http://localhost:${PORT}`));
