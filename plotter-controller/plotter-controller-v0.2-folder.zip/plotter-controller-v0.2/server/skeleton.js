// Single-stroke ("one line") glyphs: rasterize the outline, thin it (Zhang-Suen), trace and simplify.
// Works for any TTF (Cyrillic, õäöü...). Result: polylines in em units, origin = pen position on the baseline.
const R = 100, PAD = 8;
const cache = new WeakMap();

function flat(cmds) {
  const polys = []; let cur, x = 0, y = 0;
  for (const c of cmds) {
    if (c.type === 'M') { cur = [[c.x, c.y]]; polys.push(cur); }
    else if (c.type === 'L') cur.push([c.x, c.y]);
    else if (c.type === 'Q') for (let i = 1; i <= 8; i++) { const t = i / 8, u = 1 - t; cur.push([u * u * x + 2 * u * t * c.x1 + t * t * c.x, u * u * y + 2 * u * t * c.y1 + t * t * c.y]); }
    else if (c.type === 'C') for (let i = 1; i <= 10; i++) { const t = i / 10, u = 1 - t;
      cur.push([u ** 3 * x + 3 * u * u * t * c.x1 + 3 * u * t * t * c.x2 + t ** 3 * c.x, u ** 3 * y + 3 * u * u * t * c.y1 + 3 * u * t * t * c.y2 + t ** 3 * c.y]); }
    if (c.x !== undefined) { x = c.x; y = c.y; }
  }
  return polys;
}
function raster(polys, W, H) {
  const g = new Uint8Array(W * H);
  for (let r = 0; r < H; r++) {
    const yc = r + 0.5, xs = [];
    for (const p of polys) for (let i = 0; i < p.length; i++) {
      const a = p[i], b = p[(i + 1) % p.length];
      if ((a[1] <= yc) !== (b[1] <= yc)) xs.push([a[0] + (yc - a[1]) / (b[1] - a[1]) * (b[0] - a[0]), b[1] > a[1] ? 1 : -1]);
    }
    xs.sort((a, b) => a[0] - b[0]);
    let w = 0;
    for (let k = 0; k < xs.length - 1; k++) { w += xs[k][1];
      if (w) for (let c = Math.ceil(xs[k][0] - 0.5); c < xs[k + 1][0] - 0.5; c++) if (c >= 0 && c < W) g[r * W + c] = 1; }
  }
  return g;
}
function thin(g, W, H) {
  let ch = true;
  while (ch) { ch = false;
    for (let s = 0; s < 2; s++) { const del = [];
      for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) {
        const i = y * W + x; if (!g[i]) continue;
        const p = [g[i - W], g[i - W + 1], g[i + 1], g[i + W + 1], g[i + W], g[i + W - 1], g[i - 1], g[i - W - 1]];
        const B = p.reduce((a, b) => a + b, 0); if (B < 2 || B > 6) continue;
        let A = 0; for (let k = 0; k < 8; k++) if (!p[k] && p[(k + 1) % 8]) A++; if (A !== 1) continue;
        if (s === 0 ? (p[0] * p[2] * p[4] || p[2] * p[4] * p[6]) : (p[0] * p[2] * p[6] || p[0] * p[4] * p[6])) continue;
        del.push(i);
      }
      for (const i of del) g[i] = 0; if (del.length) ch = true; } }
  // remove staircase corner pixels (two perpendicular orthogonal neighbours) -> clean 1-px curves
  for (let again = true; again;) { again = false;
    for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) { const i = y * W + x; if (!g[i]) continue;
      const N = g[i - W], E = g[i + 1], S = g[i + W], Wt = g[i - 1];
      const diag = g[i - W + 1] + g[i + W + 1] + g[i + W - 1] + g[i - W - 1];
      if (diag === 0 && N + E + S + Wt === 2 && !((N && S) || (E && Wt))) { g[i] = 0; again = true; } } }
}
function trace(g, W, H) {
  // Greedy walk along skeleton pixels: start at endpoints, keep going straight where possible; mark pixels visited.
  const nb = i => { const x = i % W, y = (i / W) | 0, o = [];
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const X = x + dx, Y = y + dy;
      if ((dx || dy) && X >= 0 && X < W && Y >= 0 && Y < H && g[Y * W + X]) o.push(Y * W + X); } return o; };
  const pix = []; for (let i = 0; i < g.length; i++) if (g[i]) pix.push(i);
  const vis = new Set(), out = [];
  const walk = s0 => {
    const touching = nb(s0).some(q => vis.has(q));
    const path = [s0]; vis.add(s0); let cur = s0, dir = null;
    for (;;) {
      const c = nb(cur).filter(q => !vis.has(q)); if (!c.length) break;
      let best = c[0], bs = -9;
      for (const q of c) { const d = [(q % W) - (cur % W), ((q / W) | 0) - ((cur / W) | 0)];
        const sc = (dir ? (d[0] * dir[0] + d[1] * dir[1]) / Math.hypot(...d) : 0) - (d[0] && d[1] ? 0.01 : 0);
        if (sc > bs) { bs = sc; best = q; } }
      dir = [(best % W) - (cur % W), ((best / W) | 0) - ((cur / W) | 0)]; path.push(best); vis.add(best); cur = best;
    }
    if (path.length > 3 && nb(cur).includes(s0)) path.push(s0); // close loops (О, 0)
    if (touching && path.length < 4) return; // spur next to an already traced line
    out.push(path);
  };
  for (const i of pix) if (nb(i).length === 1 && !vis.has(i)) walk(i);
  for (const i of pix) if (!vis.has(i)) walk(i);
  return out.map(s => s.map(i => [i % W + 0.5, ((i / W) | 0) + 0.5]));
}
function rdp(pts, e) {
  if (pts.length < 3) return pts;
  const [a, b] = [pts[0], pts[pts.length - 1]]; let m = 0, k = 0;
  if (a[0] === b[0] && a[1] === b[1]) { // closed loop: split at the farthest point
    let f = 0; pts.forEach((p, i) => { const d = Math.hypot(p[0] - a[0], p[1] - a[1]); if (d > f) { f = d; k = i; } });
    if (!k) return [a, b];
    return [...rdp(pts.slice(0, k + 1), e).slice(0, -1), ...rdp(pts.slice(k), e)];
  }
  const L = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1;
  for (let i = 1; i < pts.length - 1; i++) { const d = Math.abs((b[0] - a[0]) * (a[1] - pts[i][1]) - (a[0] - pts[i][0]) * (b[1] - a[1])) / L; if (d > m) { m = d; k = i; } }
  return m > e ? [...rdp(pts.slice(0, k + 1), e).slice(0, -1), ...rdp(pts.slice(k), e)] : [a, b];
}
function glyphStrokes(font, ch) {
  let m = cache.get(font); if (!m) cache.set(font, (m = new Map()));
  if (m.has(ch)) return m.get(ch);
  const glyph = font.charToGlyph(ch), adv = (glyph.advanceWidth || 0) / font.unitsPerEm * R;
  const W = Math.ceil(adv) + 2 * PAD + 20, H = Math.ceil(R * 1.8), base = Math.round(R * 1.25);
  const polys = flat(glyph.getPath(PAD, base, R).commands);
  let strokes = [];
  if (polys.length) { const g = raster(polys, W, H); thin(g, W, H);
    strokes = trace(g, W, H).map(s => rdp(s.length === 1 ? [s[0], s[0]] : s, 1.2).map(([x, y]) => [(x - PAD) / R, (y - base) / R])).filter(s => s.length > 1); }
  m.set(ch, strokes); return strokes;
}
module.exports = { glyphStrokes };
