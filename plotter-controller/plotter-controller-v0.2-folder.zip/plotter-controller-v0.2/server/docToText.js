// PDF (mupdf), DOCX (jszip + XML), TXT/MD as is -> plain text
const JSZip = require('jszip');
const ent = s => s.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'")
  .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(+n)).replace(/&amp;/g, '&');

async function docToText(name, buf) {
  const ext = (name.split('.').pop() || '').toLowerCase();
  if (ext === 'pdf') {
    const mupdf = await import('mupdf'); // ESM-only package
    const doc = mupdf.Document.openDocument(buf, 'application/pdf');
    const out = [];
    for (let i = 0; i < doc.countPages(); i++) out.push(doc.loadPage(i).toStructuredText().asText().trim());
    return out.join('\n\n');
  }
  if (ext === 'docx') {
    const xml = await (await JSZip.loadAsync(buf)).file('word/document.xml')?.async('string');
    if (!xml) throw new Error('Not a valid DOCX (word/document.xml missing)');
    return xml.replace(/<w:tab\/>/g, '\t').replace(/<w:br[^>]*\/>/g, '\n').split('</w:p>')
      .map(p => ent(p.replace(/<[^>]+>/g, ''))).join('\n').replace(/\n{3,}/g, '\n\n').trim();
  }
  if (['txt', 'md', 'markdown', ''].includes(ext)) return buf.toString('utf8');
  throw new Error('Unsupported file type: .' + ext);
}
module.exports = { docToText };
