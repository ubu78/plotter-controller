const { svgToGcode } = require('./svgToGcode');
const r = svgToGcode('<svg width="100mm" height="100mm" viewBox="0 0 100 100"><rect x="0" y="0" width="100" height="100"/><circle cx="50" cy="50" r="30"/></svg>', { center: false, margin: 10 });
console.log(r.gcode.split('\n').slice(0, 8).join('\n'), '\n...', r.warnings, r.bbox);
if (!r.paths.length || r.bbox[0] !== 10) { console.error('FAIL'); process.exit(1); }
console.log('OK');
(async () => {
  const fs = require('fs'), opentype = require('opentype.js');
  const f = ['/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'].find(fs.existsSync);
  if (!f) return console.log('skip text test (no system font)');
  const b = fs.readFileSync(f), fontObject = opentype.parse(b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength));
  const { textToGcode } = require('./textToGcode');
  const r = await textToGcode('Тест õäöü. ' + 'слово '.repeat(60), { fontObject, startX: 20, startY: 12, singleLine: false });
  console.log('text:', r.paths.length, 'contours', r.bbox.map(n => n.toFixed(1)), r.warnings);
  if (!r.paths.length || r.bbox[0] < 19.5 || r.bbox[1] < 12 || r.bbox[2] > 210.5) { console.error('TEXT FAIL'); process.exit(1); }
  console.log('TEXT OK');
  const one = await textToGcode('Оо Жa ä.', { fontObject });
  const o2 = await textToGcode('О', { fontObject });
  console.log('single-line:', one.paths.length, 'strokes;  "О" ->', o2.paths.length, 'stroke(s), bbox', one.bbox.map(n => n.toFixed(1)));
  if (!one.paths.length || o2.paths.length !== 1 || one.bbox[0] < -0.1) { console.error('SINGLE FAIL'); process.exit(1); }
  console.log('SINGLE OK');
})();

(async () => {
  const JSZip = require('jszip'), { docToText } = require('./docToText');
  const z = new JSZip(); z.file('word/document.xml', '<w:document><w:body><w:p><w:r><w:t>Привет &amp; tere</w:t></w:r></w:p><w:p><w:r><w:t>õäöü</w:t></w:r></w:p></w:body></w:document>');
  const t = await docToText('a.docx', await z.generateAsync({ type: 'nodebuffer' }));
  if (t !== 'Привет & tere\nõäöü') { console.error('DOCX FAIL', JSON.stringify(t)); process.exit(1); } console.log('DOCX OK');
  const pdf = '%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 200 200]/Contents 4 0 R/Resources<</Font<</F1 5 0 R>>>>>>endobj\n4 0 obj<</Length 44>>stream\nBT /F1 18 Tf 20 100 Td (Hello PDF) Tj ET\nendstream endobj\n5 0 obj<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>endobj\ntrailer<</Root 1 0 R/Size 6>>\n%%EOF';
  console.log('PDF:', JSON.stringify(await docToText('a.pdf', Buffer.from(pdf)).catch(e => 'ERR ' + e.message)));
})();
