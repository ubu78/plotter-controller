// Text/Markdown -> G-code. (text, options) => { gcode, warnings, paths, bbox, paper }
const opentype = require('opentype.js');
const fs = require('fs'), path = require('path'), os = require('os');
const { svgToGcode, PAPERS } = require('./svgToGcode');
const { glyphStrokes } = require('./skeleton');

const CACHE = path.join(os.homedir(), '.cache', 'plotter-controller', 'fonts');
const FONTS = ['Roboto', 'Open Sans', 'PT Sans', 'PT Serif', 'Noto Serif', 'Lora', 'Playfair Display',
  'Ubuntu', 'Comfortaa', 'Caveat', 'Marck Script', 'Neucha', 'Philosopher', 'Underdog'];
const TEST = 'äöõüÄÖÕÜжЖя'; // Estonian + Cyrillic coverage probe
const SYSTEM = ['/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', '/usr/share/fonts/TTF/DejaVuSans.ttf'];

const parse = b => opentype.parse(b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength));
const missing = (font, s) => [...new Set([...s].filter(c => c.trim() && font.charToGlyphIndex(c) === 0))];

async function loadFont(name, warnings) {
  const file = path.join(CACHE, name.replace(/\W+/g, '_') + '.ttf');
  try {
    if (!fs.existsSync(file)) {
      fs.mkdirSync(CACHE, { recursive: true });
      // No browser User-Agent -> Google returns full TTF (not woff2 subsets)
      const css = await (await fetch(`https://fonts.googleapis.com/css?family=${encodeURIComponent(name)}&subset=cyrillic,latin`)).text();
      const urls = [...css.matchAll(/url\((https:[^)]+)\)/g)].map(m => m[1]);
      if (!urls.length) throw new Error('Font not found: ' + name);
      let best = null, bestScore = -1;
      for (const u of new Set(urls)) {
        const buf = Buffer.from(await (await fetch(u)).arrayBuffer());
        const score = TEST.length - missing(parse(buf), TEST).length;
        if (score > bestScore) { best = buf; bestScore = score; }
      }
      fs.writeFileSync(file, best);
    }
    return parse(fs.readFileSync(file));
  } catch (e) {
    const sys = SYSTEM.find(fs.existsSync);
    if (!sys) throw new Error(`Cannot load font "${name}" (${e.message}). Internet needed for first download.`);
    warnings.push(`Font "${name}" unavailable (${e.message}); using DejaVu Sans`);
    return parse(fs.readFileSync(sys));
  }
}

const stripMd = t => t.replace(/^#{1,6}\s*/gm, '').replace(/^\s*[-*+]\s+/gm, '• ').replace(/^>\s?/gm, '')
  .replace(/(\*\*|__|\*|_|`)/g, '');

function wrap(font, text, size, maxW) {
  const out = [];
  for (const para of text.split('\n')) {
    let line = '';
    for (const w of para.split(/\s+/).filter(Boolean)) {
      const t = line ? line + ' ' + w : w;
      if (line && font.getAdvanceWidth(t, size) > maxW) { out.push(line); line = w; } else line = t;
    }
    out.push(line);
  }
  return out;
}

async function textToGcode(text, o = {}) {
  const opt = { font: 'Roboto', size: 6, lineHeight: 1.4, markdown: false, paper: 'A4', margin: 0, startX: 0, startY: 0, singleLine: true, ...o };
  const warnings = [];
  const font = opt.fontObject || await loadFont(opt.font, warnings);
  if (opt.markdown) text = stripMd(text);
  let [pw, ph] = opt.paper === 'custom' ? [opt.paperW, opt.paperH] : PAPERS[opt.paper] || PAPERS.A4;
  pw = Math.min(pw, 210); ph = Math.min(ph, 297);
  const miss = missing(font, text);
  if (miss.length) warnings.push('Font has no glyphs for: ' + miss.join(' '));

  let lines = wrap(font, text, opt.size, pw - opt.startX - opt.margin);
  const step = opt.size * opt.lineHeight, maxLines = Math.max(1, Math.floor((ph - opt.startY - opt.margin - opt.size) / step) + 1);
  const pages = Math.max(1, Math.ceil(lines.length / maxLines)); let page = Math.min(Math.max(opt.page | 0, 0), pages - 1);
  if (opt.page !== undefined) lines = lines.slice(page * maxLines, (page + 1) * maxLines);
  else if (lines.length > maxLines) { warnings.push(`Text truncated: ${lines.length - maxLines} line(s) do not fit on the sheet`); lines = lines.slice(0, maxLines); }
  while (lines.length && !lines[lines.length - 1]) lines.pop();

  let d = '';
  lines.forEach((l, i) => {
    if (!l) return; const base = opt.size * 0.8 + i * step;
    if (!opt.singleLine) { d += font.getPath(l, 0, base, opt.size).toPathData(2); return; }
    let x = 0; // single-stroke: centre-line of every glyph, one pen line per stroke
    for (const ch of l) {
      for (const st of glyphStrokes(font, ch)) d += 'M' + st.map(([a, b]) => `${(x + a * opt.size).toFixed(2)} ${(base + b * opt.size).toFixed(2)}`).join('L');
      x += font.getAdvanceWidth(ch, opt.size);
    }
  });
  if (!d) return { gcode: '', warnings: [...warnings, 'Nothing to draw'], paths: [], bbox: null, paper: [pw, ph], pages, page };
  // 1 SVG unit = 1 mm; top-left of the text block sits at the margin (+ drag offset)
  const svg = `<svg width="1mm" height="1mm" viewBox="0 0 1 1"><path d="${d}"/></svg>`;
  const r = svgToGcode(svg, { ...opt, center: false, scale: 100, keepOrigin: true, margin: 0, offsetX: opt.startX, offsetY: opt.startY });
  r.warnings = [...warnings, ...r.warnings]; r.pages = pages; r.page = page;
  return r;
}
module.exports = { textToGcode, FONTS, loadFont };
