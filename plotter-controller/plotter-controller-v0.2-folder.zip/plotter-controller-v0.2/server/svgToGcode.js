// SVG -> G-code. (svg, options) => { gcode, warnings, paths, bbox }
const { parseSVG, makeAbsolute } = require('svg-path-parser');
const PAPERS = { A4: [210, 297], A5: [148, 210], Letter: [215.9, 279.4] };
const MAX = [210, 297];
const UNITS = { mm: 1, cm: 10, in: 25.4, px: 25.4 / 96, pt: 25.4 / 72, '': 25.4 / 96 };

const attrs = s => { const o = {}; s.replace(/([\w:-]+)\s*=\s*"([^"]*)"/g, (_, k, v) => (o[k] = v)); return o; };
const num = (v, d = 0) => (v === undefined ? d : parseFloat(v));

function shapes(svg) {
  const out = [];
  svg.replace(/<(path|rect|circle|ellipse|line|polyline|polygon)\b([^>]*)>/g, (_, t, a) => {
    const p = attrs(a); let d = null;
    if (t === 'path') d = p.d;
    else if (t === 'line') d = `M${num(p.x1)} ${num(p.y1)}L${num(p.x2)} ${num(p.y2)}`;
    else if (t === 'rect') { const x = num(p.x), y = num(p.y), w = num(p.width), h = num(p.height); d = `M${x} ${y}h${w}v${h}h${-w}z`; }
    else if (t === 'polyline' || t === 'polygon') { const n = (p.points || '').trim().split(/[\s,]+/).map(Number); d = 'M' + n.join(' ').replace(/^(\S+ \S+)/, '$1 L'); if (t === 'polygon') d += 'z'; }
    else { const cx = num(p.cx), cy = num(p.cy), rx = num(p.rx ?? p.r), ry = num(p.ry ?? p.r), k = 0.5523;
      d = `M${cx + rx} ${cy}C${cx + rx} ${cy + ry * k} ${cx + rx * k} ${cy + ry} ${cx} ${cy + ry}C${cx - rx * k} ${cy + ry} ${cx - rx} ${cy + ry * k} ${cx - rx} ${cy}C${cx - rx} ${cy - ry * k} ${cx - rx * k} ${cy - ry} ${cx} ${cy - ry}C${cx + rx * k} ${cy - ry} ${cx + rx} ${cy - ry * k} ${cx + rx} ${cy}z`; }
    if (d) out.push({ d, transform: p.transform });
  });
  return out;
}

function flatten(d, warnings, seg = 16) {
  const polys = []; let cur = null, x = 0, y = 0, sx = 0, sy = 0, lc = null, lq = null;
  const add = (px, py) => { if (!cur) { cur = [[x, y]]; polys.push(cur); } cur.push([px, py]); x = px; y = py; };
  const bez = (pts) => { const [p0, p1, p2, p3] = pts;
    for (let i = 1; i <= seg; i++) { const t = i / seg, u = 1 - t;
      const f = k => u ** 3 * p0[k] + 3 * u * u * t * p1[k] + 3 * u * t * t * p2[k] + t ** 3 * p3[k]; add(f(0), f(1)); } };
  for (const c of makeAbsolute(parseSVG(d))) {
    const k = c.code; let nlc = null, nlq = null;
    if (k === 'M') { x = sx = c.x; y = sy = c.y; cur = [[x, y]]; polys.push(cur); }
    else if (k === 'L') add(c.x, c.y);
    else if (k === 'H') add(c.x, y);
    else if (k === 'V') add(x, c.y);
    else if (k === 'C') { const p0 = [x, y]; bez([p0, [c.x1, c.y1], [c.x2, c.y2], [c.x, c.y]]); nlc = [c.x2, c.y2]; }
    else if (k === 'S') { const p0 = [x, y], r = lc ? [2 * x - lc[0], 2 * y - lc[1]] : p0; bez([p0, r, [c.x2, c.y2], [c.x, c.y]]); nlc = [c.x2, c.y2]; }
    else if (k === 'Q' || k === 'T') { const p0 = [x, y]; const q = k === 'Q' ? [c.x1, c.y1] : lq ? [2 * x - lq[0], 2 * y - lq[1]] : p0;
      bez([p0, [p0[0] + 2 / 3 * (q[0] - p0[0]), p0[1] + 2 / 3 * (q[1] - p0[1])], [c.x + 2 / 3 * (q[0] - c.x), c.y + 2 / 3 * (q[1] - c.y)], [c.x, c.y]]); nlq = q; }
    else if (k === 'A') { warnings.push('Arc (A) approximated by a straight line'); add(c.x, c.y); }
    else if (k === 'Z') { if (cur) cur.push([sx, sy]); x = sx; y = sy; cur = null; }
    lc = nlc; lq = nlq;
  }
  return polys.filter(p => p.length > 1);
}

function svgToGcode(svg, o = {}) {
  const opt = { paper: 'A4', margin: 0, scale: 100, center: false, offsetX: 0, offsetY: 0, feed: 3000, penMode: 'z',
    zUp: 5, zDown: 0, zFeed: 500, servoDown: 'M3 S90', servoUp: 'M5', ...o };
  const warnings = [];
  let [pw, ph] = opt.paper === 'custom' ? [opt.paperW, opt.paperH] : PAPERS[opt.paper] || MAX;
  if (pw > MAX[0] || ph > MAX[1]) { warnings.push('Paper limited to A4 (210×297 mm)'); pw = Math.min(pw, MAX[0]); ph = Math.min(ph, MAX[1]); }

  const root = (svg.match(/<svg\b([^>]*)>/) || [])[1] || '';
  const ra = attrs(root);
  const wm = (ra.width || '').match(/^([\d.]+)\s*([a-z%]*)$/);
  const vb = (ra.viewBox || '').trim().split(/[\s,]+/).map(Number);
  let unit = UNITS.px;
  if (wm && UNITS[wm[2]] !== undefined) unit = vb.length === 4 ? (parseFloat(wm[1]) * UNITS[wm[2]]) / vb[2] : UNITS[wm[2]];

  let polys = [];
  for (const s of shapes(svg)) {
    if (s.transform) warnings.push('transform attribute ignored');
    try { polys.push(...flatten(s.d, warnings)); } catch (e) { warnings.push('Bad path skipped: ' + e.message); }
  }
  if (!polys.length) return { gcode: '', warnings: [...warnings, 'No drawable shapes found'], paths: [], bbox: null, paper: [pw, ph] };
  warnings.splice(0, warnings.length, ...new Set(warnings));

  const bb = a => { let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
    for (const p of a) for (const [x, y] of p) { x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x); y1 = Math.max(y1, y); } return [x0, y0, x1, y1]; };
  let s = unit * (opt.scale / 100);
  let [x0, y0, x1, y1] = bb(polys);
  if (opt.keepOrigin) { x0 = 0; y0 = 0; } // layout coordinates are already in mm from the block origin
  let w = (x1 - x0) * s, h = (y1 - y0) * s;
  const aw = pw - 2 * opt.margin, ah = ph - 2 * opt.margin;
  if (!opt.keepOrigin && (w > aw || h > ah)) { const f = Math.min(aw / w, ah / h); s *= f; w *= f; h *= f; warnings.push(`Auto-scaled to ${(f * 100).toFixed(0)}% to fit paper`); }
  const ox = (opt.center ? (pw - w) / 2 : opt.margin) + opt.offsetX, oy = (opt.center ? (ph - h) / 2 : opt.margin) + opt.offsetY; // origin = top-left, Y down
  const paths = polys.map(p => p.map(([x, y]) => [(x - x0) * s + ox, (y - y0) * s + oy]));
  const [bx0, by0, bx1, by1] = bb(paths);
  if (bx0 < 0 || by0 < 0 || bx1 > pw || by1 > ph) warnings.push('Drawing exceeds paper after offset');

  const up = opt.penMode === 'z' ? `G0 Z${opt.zUp}` : `${opt.servoUp}\nG4 P0.2`;
  const down = opt.penMode === 'z' ? `G1 Z${opt.zDown} F${opt.zFeed}` : `${opt.servoDown}\nG4 P0.2`;
  const f = n => n.toFixed(3);
  const g = ['; Plotter Controller — SVG', 'G21 G90', up];
  for (const p of paths) {
    g.push(`G0 X${f(p[0][0])} Y${f(p[0][1])}`, down);
    for (const [x, y] of p.slice(1)) g.push(`G1 X${f(x)} Y${f(y)} F${opt.feed}`);
    g.push(up);
  }
  g.push('G0 X0 Y0');
  return { gcode: g.join('\n'), warnings, paths, bbox: [bx0, by0, bx1, by1], paper: [pw, ph] };
}
module.exports = { svgToGcode, PAPERS };
