// GRBL 1.1 connection: strict flow control (one line in flight, wait for ok/error)
const { EventEmitter } = require('events');
const { SerialPort, ReadlineParser } = require('serialport');

class Grbl extends EventEmitter {
  constructor() {
    super();
    this.port = null; this.queue = []; this.busy = false; this.streaming = false;
    this.total = 0; this.sent = 0; this.settings = {};
    this.status = { connected: false, state: 'Disconnected', wpos: [0, 0, 0], wco: [0, 0, 0], progress: 0 };
  }
  static list() { return SerialPort.list(); }
  connect(path, baud = 115200) {
    return new Promise((resolve, reject) => {
      if (this.port) return reject(new Error('Already connected'));
      const p = new SerialPort({ path, baudRate: Number(baud) }, err => {
        if (err) return reject(err);
        this.port = p; this.status.connected = true; this.status.state = 'Connecting';
        this.emit('status', this.status); resolve();
        this.poll = setInterval(() => this.rt('?'), 250);
      });
      p.pipe(new ReadlineParser({ delimiter: '\n' })).on('data', l => this._line(l.trim()));
      p.on('close', () => this._closed());
      p.on('error', e => this.emit('log', 'ERR ' + e.message));
    });
  }
  disconnect() { return new Promise(r => { if (!this.port) return r(); this.port.close(() => r()); }); }
  _closed() {
    clearInterval(this.poll); this.port = null; this.queue = []; this.busy = false; this.streaming = false;
    this.status = { ...this.status, connected: false, state: 'Disconnected', progress: 0 };
    this.emit('status', this.status);
  }
  rt(ch) { if (this.port) this.port.write(ch); } // realtime: ? ! ~ 0x18 0x85
  _line(l) {
    if (!l) return;
    if (l[0] === '<') return this._status(l);
    const m = l.match(/^\$(\d+)=(.+)$/);
    if (m) { this.settings[m[1]] = m[2]; this.emit('setting'); }
    this.emit('log', '< ' + l); // error texts are localized in the UI
    if (l === 'ok' || l.startsWith('error:') || l.startsWith('ALARM:')) {
      if (!l.startsWith('ALARM:')) { this.busy = false; this.sent++; this._next(); }
      if (l.startsWith('error:') && this.streaming) this.emit('log', '! stream continues after ' + l);
    }
  }
  _status(l) {
    const f = l.slice(1, -1).split('|'); const st = this.status; st.state = f[0].split(':')[0];
    for (const x of f.slice(1)) {
      const [k, v] = x.split(':'); if (!v) continue;
      const n = v.split(',').map(Number);
      if (k === 'WCO') st.wco = n;
      if (k === 'WPos') st.wpos = n;
      if (k === 'MPos') st.wpos = n.map((a, i) => a - (st.wco[i] || 0));
    }
    st.progress = this.total ? this.sent / this.total : 0;
    this.emit('status', st);
  }
  send(line) { this.queue.push(line); this.total++; this._next(); }
  stream(gcode) {
    const lines = gcode.split('\n').map(s => s.replace(/;.*$/, '').trim()).filter(Boolean);
    this.total = lines.length; this.sent = 0; this.streaming = true; this.queue.push(...lines); this._next();
  }
  _next() {
    if (this.busy || !this.port) return;
    const l = this.queue.shift();
    if (l === undefined) { if (this.streaming) { this.streaming = false; this.emit('log', '-- done --'); } return; }
    this.busy = true; this.emit('log', '> ' + l); this.port.write(l + '\n');
  }
  hold() { this.rt('!'); }
  resume() { this.rt('~'); }
  reset() { this.queue = []; this.busy = false; this.streaming = false; this.total = this.sent = 0; this.rt('\x18'); }
  jogCancel() { this.queue = []; this.rt('\x85'); }
}
module.exports = Grbl;
