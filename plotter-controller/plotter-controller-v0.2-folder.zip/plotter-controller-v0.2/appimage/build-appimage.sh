#!/usr/bin/env bash
# Plotter Controller -> self-contained AppImage (Linux x86_64, bundled Node.js, no install needed)
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/release"; B="$ROOT/.appimage-build"; A="$B/AppDir"; NODE_MAJOR="${NODE_MAJOR:-20}"
rm -rf "$B"; mkdir -p "$A/usr/bin" "$A/usr/app" "$OUT"

echo "==> 1/5 vite build"
cd "$ROOT"; [ -d node_modules ] || npm install; npx vite build

echo "==> 2/5 production dependencies (linux-x64 only)"
cp -r server dist package.json "$A/usr/app/"; [ -f package-lock.json ] && cp package-lock.json "$A/usr/app/"
( cd "$A/usr/app"; npm install --omit=dev --no-audit --no-fund --os=linux --cpu=x64 )
# drop prebuilds for other platforms (serialport etc.)
find "$A/usr/app/node_modules" -type d -name prebuilds | while read -r d; do
  for p in "$d"/*; do [ "$(basename "$p")" = "linux-x64" ] || rm -rf "$p"; done; done
rm -rf "$A/usr/app/node_modules/.cache"

echo "==> 3/5 bundled Node.js $NODE_MAJOR (npm package node-linux-x64)"
( cd "$B"; tgz="$(npm pack "node-linux-x64@$NODE_MAJOR" --silent | tail -1)"; tar xzf "$tgz" package/bin/node )
install -m755 "$B/package/bin/node" "$A/usr/bin/node"

echo "==> 4/5 AppDir"
cat > "$A/AppRun" <<'RUN'
#!/bin/sh
H="$(dirname "$(readlink -f "$0")")"; PORT="${PORT:-8765}"; export PORT
id -nG | tr ' ' '\n' | grep -qx dialout || echo "Note: add yourself to the 'dialout' group for serial access: sudo usermod -aG dialout \$USER (then re-login)" >&2
cd "$H/usr/app"; "$H/usr/bin/node" server/server.js & P=$!
trap 'kill $P 2>/dev/null' INT TERM EXIT
sleep 1; (xdg-open "http://localhost:$PORT" >/dev/null 2>&1 || true); wait $P
RUN
chmod +x "$A/AppRun"
cat > "$A/plotter-controller.desktop" <<'DESK'
[Desktop Entry]
Type=Application
Name=Plotter Controller
Name[ru]=Управление плоттером
Name[et]=Plotteri juhtimine
Exec=AppRun
Icon=plotter-controller
Categories=Utility;Electronics;
Terminal=false
DESK
cat > "$A/plotter-controller.svg" <<'SVG'
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128"><rect width="128" height="128" rx="22" fill="#1f6feb"/><path d="M24 96 L56 40 L72 68 L104 28" fill="none" stroke="#fff" stroke-width="8" stroke-linecap="round" stroke-linejoin="round"/><circle cx="104" cy="28" r="8" fill="#fff"/></svg>
SVG

echo "==> 5/5 appimagetool"
TOOL="$B/appimagetool"
[ -x "$TOOL" ] || { curl -fL -o "$TOOL" https://github.com/AppImage/appimagetool/releases/download/continuous/appimagetool-x86_64.AppImage; chmod +x "$TOOL"; }
VER="$(node -p "require('$ROOT/package.json').version")"
ARCH=x86_64 "$TOOL" --appimage-extract-and-run "$A" "$OUT/Plotter-Controller-$VER-x86_64.AppImage"
ls -lh "$OUT"
